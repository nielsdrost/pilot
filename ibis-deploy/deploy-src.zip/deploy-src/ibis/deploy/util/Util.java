package ibis.deploy.util;

/**
 * Some utility functions of Ibis-Deploy
 */
public class Util {

 

}