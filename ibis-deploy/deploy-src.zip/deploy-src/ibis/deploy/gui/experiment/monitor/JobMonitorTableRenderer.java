package ibis.deploy.gui.experiment.monitor;

import ibis.deploy.Job;
import ibis.deploy.JobDescription;
import ibis.deploy.State;
import ibis.deploy.gui.misc.Utils;
import ibis.deploy.util.Colors;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableCellRenderer;

class JobMonitorTableRenderer extends JLabel implements TableCellRenderer {

    private static final long serialVersionUID = -1269380843774208099L;

    private final JobMonitorTableModel model;

    public JobMonitorTableRenderer(JobMonitorTableModel model) {
        super();
        this.model = model;
    }

    public Component getTableCellRendererComponent(final JTable table,
            final Object value, boolean isSelected, boolean hasFocus,
            final int row, int column) {
        setBorder(new EmptyBorder(5, 5, 5, 5));
        setText("");
        setOpaque(isSelected);

        setBackground(UIManager.getColor("Table.selectionBackground"));
        setForeground(Color.BLACK);

        String columnName = table.getColumnName(column);

        if (columnName.equalsIgnoreCase(JobMonitorTableModel.POOL_COLUMN_NAME)) {
            setText("" + value);
        } else if (columnName.equalsIgnoreCase(JobMonitorTableModel.NAME_COLUMN_NAME)) {
            setText("" + value);
        } else if (columnName
                .equalsIgnoreCase(JobMonitorTableModel.JOB_STATUS_COLUMN_NAME)) {
            State state = (State) value;

            if (state != null && state != State.UNKNOWN) {
                if (state == State.DEPLOYED) {
                    // green
                    setForeground(Color.decode("#16B400"));
                } else if (state == State.ERROR) {
                    setForeground(Color.RED);
                } else {
                    setForeground(Color.BLACK);
                }

                setText(state.toString());
            }
        } else if (columnName
                .equalsIgnoreCase(JobMonitorTableModel.HUB_STATUS_COLUMN_NAME)) {
            State state = (State) value;

            if (state != null && state != State.UNKNOWN) {
                if (state == State.DEPLOYED) {
                    // green
                    setForeground(Color.decode("#16B400"));
                } else if (state == State.ERROR) {
                    setForeground(Color.RED);
                } else {
                    setForeground(Color.BLACK);
                }

                setText(state.toString());
            }
        } else if (columnName
                .equalsIgnoreCase(JobMonitorTableModel.RESOURCE_COLUMN_NAME)) {
            setOpaque(true);

            JobDescription jobDescription = model.getJobDescription(table
                    .convertRowIndexToModel(row));

            if (isSelected) {
                setBackground(jobDescription
                        .getResource().getColor());
            } else {
                setBackground(Colors.getLightColor(jobDescription
                        .getResource().getColor()));
            }

            setText(jobDescription.getResource().getName());
        } else if (columnName
                .equalsIgnoreCase(JobMonitorTableModel.MIDDLEWARE_COLUMN_NAME)) {
            String adaptor = (String) value;
            if (adaptor != null && adaptor.equalsIgnoreCase("sshTrilead")) {
                adaptor = "ssh";
            }
            setText(adaptor);
        } else if (columnName
                .equalsIgnoreCase(JobMonitorTableModel.APPLICATION_COLUMN_NAME)) {
            setText("" + value);
        } else if (columnName
                .equalsIgnoreCase(JobMonitorTableModel.PROCESS_COUNT_COLUMN_NAME)) {
            setText("" + value);
        } else if (columnName
                .equalsIgnoreCase(JobMonitorTableModel.RESOURCE_COUNT_COLUMN_NAME)) {
            setText("" + value);
        } else if (columnName
                .equalsIgnoreCase(JobMonitorTableModel.RUNTIME_COLUMN_NAME)) {
            setText("" + value);
        } else if (columnName
                .equalsIgnoreCase(JobMonitorTableModel.OUTPUT_COLUMN_NAME)) {
            boolean enabled = false;
            if (value != null) {
                enabled = (Boolean) value;
            }

            final Job job = model.getJob(table.convertRowIndexToModel(row));

            final JButton button = Utils.createImageButton(

            null, "Show output of job", "output");

            // JButton button = new JButton("output");
            // button.setMargin(new Insets(2, 2, 2, 2));
            // button.setPreferredSize(new Dimension(10, 10));
            button.addActionListener(new ActionListener() {

                public void actionPerformed(ActionEvent arg0) {
                    System.err.println("Output!");
                    JDialog dialog = new JDialog(SwingUtilities
                            .getWindowAncestor(table), "Output Files for "
                            + job.getDescription().getName());
                    dialog.setContentPane(new JobMonitorOutputPanel(job));
                    dialog.pack();
                    dialog.setLocationRelativeTo(SwingUtilities
                            .getWindowAncestor(table));
                    dialog.setVisible(true);

                }

            });
            button.setEnabled(enabled);

            return button;
        }
        return this;
    }
}
