package ibis.deploy.monitoring.collection.exceptions;

public class IsAnIbisMetricException extends Exception{
	private static final long serialVersionUID = 23951635983063657L;

}
