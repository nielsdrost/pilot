package ibis.deploy.monitoring.collection.exceptions;

public class IncorrectParametersException extends Exception {
	private static final long serialVersionUID = -1713295336538789851L;

}
