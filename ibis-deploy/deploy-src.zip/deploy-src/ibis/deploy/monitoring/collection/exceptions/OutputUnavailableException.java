package ibis.deploy.monitoring.collection.exceptions;

public class OutputUnavailableException extends Exception {
	private static final long serialVersionUID = 8427319091610532996L;

}
