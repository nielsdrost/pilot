package ibis.deploy.monitoring.collection.exceptions;

public class NotALinkMetricException extends Exception {
	private static final long serialVersionUID = -5296802846174253155L;

}
