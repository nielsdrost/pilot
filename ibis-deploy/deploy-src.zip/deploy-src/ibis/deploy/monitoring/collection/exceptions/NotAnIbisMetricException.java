package ibis.deploy.monitoring.collection.exceptions;

public class NotAnIbisMetricException extends Exception {
	private static final long serialVersionUID = -4485059931316317795L;

}
