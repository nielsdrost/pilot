package ibis.deploy.monitoring.collection.exceptions;

public class IncorrectElementException extends Exception {
	private static final long serialVersionUID = 4949548922771499373L;

}
