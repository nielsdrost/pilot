package ibis.deploy.monitoring.visualization.gridvision.exceptions;

public class MetricDescriptionNotAvailableException extends Exception {
	private static final long serialVersionUID = 3355872605026008258L;
	
	public MetricDescriptionNotAvailableException(String string) {
		super(string);
	}

}
