package ibis.deploy.monitoring.visualization.gridvision;

public interface Moveable {
	public void doMoveFraction(float fractionCompleted);
}
